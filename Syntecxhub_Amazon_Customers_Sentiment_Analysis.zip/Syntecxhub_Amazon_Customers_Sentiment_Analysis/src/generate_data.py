"""
generate_data.py
-----------------
Creates a realistic synthetic Amazon product-reviews dataset so the sentiment
analysis pipeline can run end-to-end without needing external downloads.

If you have a real Kaggle "Amazon Product Reviews" CSV, just drop it into
data/amazon_reviews.csv with columns: product, rating, date, review_text
and skip running this script — main.py will use whatever is already there.
"""

import random
import pandas as pd
from datetime import datetime, timedelta

random.seed(42)

PRODUCTS = [
    "Wireless Bluetooth Earbuds", "Stainless Steel Water Bottle",
    "4K Action Camera", "Ergonomic Office Chair", "Smart Fitness Watch",
    "Portable Phone Charger", "Noise Cancelling Headphones",
    "Non-Stick Frying Pan Set", "LED Desk Lamp", "Mechanical Keyboard",
]

POSITIVE_SNIPPETS = [
    "absolutely love this product, works perfectly",
    "great quality for the price, highly recommend",
    "exceeded my expectations, will buy again",
    "fast shipping and excellent build quality",
    "amazing value, exactly as described",
    "works flawlessly and looks great too",
    "very happy with this purchase, five stars",
    "battery life is fantastic and setup was easy",
    "sturdy, well made, and comfortable to use",
    "best purchase I've made this year",
]

NEGATIVE_SNIPPETS = [
    "stopped working after two days, very disappointed",
    "poor quality, broke almost immediately",
    "not as described, feels cheap and flimsy",
    "waste of money, would not recommend",
    "customer service was unhelpful when it failed",
    "arrived damaged and packaging was terrible",
    "battery drains too fast, useless",
    "extremely uncomfortable and poorly designed",
    "the item stopped charging after a week",
    "regret buying this, returning it immediately",
]

NEUTRAL_SNIPPETS = [
    "it's okay, does the job but nothing special",
    "average product, meets basic expectations",
    "decent for the price but has some flaws",
    "works fine, though the instructions were unclear",
    "not bad, not great, exactly middle of the road",
    "shipping took a while but the product is fine",
    "does what it says, no major complaints",
    "reasonable quality, would consider other brands next time",
]

FILLERS = [
    "", " Would consider buying similar items again.",
    " The packaging was nice.", " Delivery was on time.",
    " I use it every day.", " My family also likes it.",
    " Compared to other brands, it's decent.", " I bought it as a gift.",
]


def random_date(start_days_ago=365):
    d = datetime.today() - timedelta(days=random.randint(0, start_days_ago))
    return d.strftime("%Y-%m-%d")


def make_review(sentiment_bucket):
    if sentiment_bucket == "positive":
        text = random.choice(POSITIVE_SNIPPETS)
        rating = random.choices([5, 4], weights=[0.75, 0.25])[0]
    elif sentiment_bucket == "negative":
        text = random.choice(NEGATIVE_SNIPPETS)
        rating = random.choices([1, 2], weights=[0.7, 0.3])[0]
    else:
        text = random.choice(NEUTRAL_SNIPPETS)
        rating = 3
    text = text.capitalize() + "." + random.choice(FILLERS)
    return text, rating


def generate(n=800, out_path="data/amazon_reviews.csv"):
    rows = []
    for i in range(n):
        bucket = random.choices(
            ["positive", "negative", "neutral"], weights=[0.55, 0.25, 0.20]
        )[0]
        text, rating = make_review(bucket)
        rows.append({
            "review_id": i + 1,
            "product": random.choice(PRODUCTS),
            "rating": rating,
            "date": random_date(),
            "review_text": text,
        })
    df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} synthetic reviews -> {out_path}")
    return df


if __name__ == "__main__":
    generate()
