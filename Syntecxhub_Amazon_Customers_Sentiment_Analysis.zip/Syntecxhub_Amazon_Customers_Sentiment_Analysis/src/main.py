"""
main.py
-------
End-to-end pipeline for the Amazon Customer Sentiment Analysis project.

Run:
    python src/main.py

Outputs land in outputs/:
    - sentiment_results.csv         (per-review results)
    - visualizations/*.png          (charts)
    - insights_report.md            (auto-generated written insights)
"""

import os
from collections import Counter

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from generate_data import generate
from preprocess import preprocess_series
from sentiment_model import lexicon_sentiment, rating_to_label, train_classifier

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "amazon_reviews.csv")
OUT_DIR = os.path.join(BASE_DIR, "outputs")
VIZ_DIR = os.path.join(OUT_DIR, "visualizations")

sns.set_theme(style="whitegrid")
PALETTE = {"positive": "#2E7D32", "neutral": "#F9A825", "negative": "#C62828"}


def load_data():
    if not os.path.exists(DATA_PATH):
        print("No dataset found — generating a synthetic Amazon reviews dataset...")
        df = generate(n=800, out_path=DATA_PATH)
    else:
        df = pd.read_csv(DATA_PATH)
    return df


def run_pipeline():
    os.makedirs(VIZ_DIR, exist_ok=True)
    df = load_data()

    # ---- 1. Clean & preprocess ----
    df["cleaned_text"], df["tokens"] = preprocess_series(df["review_text"])

    # ---- 2. Lexicon-based sentiment ----
    lex_results = df["tokens"].apply(lexicon_sentiment)
    df["lexicon_sentiment"] = lex_results.apply(lambda x: x[0])
    df["lexicon_score"] = lex_results.apply(lambda x: x[1])

    # ---- 3. Rating-derived label (used as ground truth proxy) ----
    df["rating_label"] = df["rating"].apply(rating_to_label)

    # ---- 4. Train supervised classifier ----
    clf, vectorizer, metrics = train_classifier(df)
    df["date"] = pd.to_datetime(df["date"])

    # ---- 5. Visualizations ----
    plot_sentiment_distribution(df)
    plot_sentiment_by_rating(df)
    plot_sentiment_trend(df)
    plot_sentiment_by_product(df)
    plot_top_words(df)
    plot_confusion_matrix(metrics)

    # ---- 6. Save results ----
    results_cols = ["review_id", "product", "rating", "date", "review_text",
                     "lexicon_sentiment", "lexicon_score", "rating_label"]
    df[results_cols].to_csv(os.path.join(OUT_DIR, "sentiment_results.csv"), index=False)

    # ---- 7. Insights report ----
    write_insights_report(df, metrics)

    print("\nPipeline complete.")
    print(f"Classifier accuracy on held-out test set: {metrics['accuracy']:.2%}")
    print(f"Results saved to: {OUT_DIR}")


def plot_sentiment_distribution(df):
    counts = df["lexicon_sentiment"].value_counts().reindex(["positive", "neutral", "negative"])
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.pie(counts, labels=counts.index, autopct="%1.1f%%", startangle=90,
           colors=[PALETTE[k] for k in counts.index])
    ax.set_title("Overall Sentiment Distribution")
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "01_sentiment_distribution.png"), dpi=150)
    plt.close(fig)


def plot_sentiment_by_rating(df):
    ct = pd.crosstab(df["rating"], df["lexicon_sentiment"])
    ct = ct.reindex(columns=["positive", "neutral", "negative"], fill_value=0)
    fig, ax = plt.subplots(figsize=(7, 5))
    ct.plot(kind="bar", stacked=True, color=[PALETTE[c] for c in ct.columns], ax=ax)
    ax.set_title("Sentiment Breakdown by Star Rating")
    ax.set_xlabel("Star Rating")
    ax.set_ylabel("Number of Reviews")
    ax.legend(title="Sentiment")
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "02_sentiment_by_rating.png"), dpi=150)
    plt.close(fig)


def plot_sentiment_trend(df):
    trend = (
        df.set_index("date")
        .groupby([pd.Grouper(freq="W"), "lexicon_sentiment"])
        .size()
        .unstack(fill_value=0)
        .reindex(columns=["positive", "neutral", "negative"], fill_value=0)
    )
    fig, ax = plt.subplots(figsize=(9, 5))
    for col in trend.columns:
        ax.plot(trend.index, trend[col], label=col, color=PALETTE[col], marker="o", markersize=3)
    ax.set_title("Weekly Sentiment Trend")
    ax.set_xlabel("Week")
    ax.set_ylabel("Number of Reviews")
    ax.legend(title="Sentiment")
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "03_sentiment_trend.png"), dpi=150)
    plt.close(fig)


def plot_sentiment_by_product(df):
    ct = pd.crosstab(df["product"], df["lexicon_sentiment"], normalize="index") * 100
    ct = ct.reindex(columns=["positive", "neutral", "negative"], fill_value=0)
    ct = ct.sort_values("negative", ascending=False)
    fig, ax = plt.subplots(figsize=(9, 6))
    ct.plot(kind="barh", stacked=True, color=[PALETTE[c] for c in ct.columns], ax=ax)
    ax.set_title("Sentiment Share (%) by Product")
    ax.set_xlabel("Percentage of Reviews")
    ax.legend(title="Sentiment", bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "04_sentiment_by_product.png"), dpi=150)
    plt.close(fig)


def plot_top_words(df):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, sentiment, color in zip(axes, ["positive", "negative"],
                                     [PALETTE["positive"], PALETTE["negative"]]):
        tokens = [t for toks in df.loc[df["lexicon_sentiment"] == sentiment, "tokens"] for t in toks]
        common = Counter(tokens).most_common(10)
        if common:
            words, freqs = zip(*common)
            ax.barh(words[::-1], freqs[::-1], color=color)
        ax.set_title(f"Top Words — {sentiment.capitalize()} Reviews")
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "05_top_words.png"), dpi=150)
    plt.close(fig)


def plot_confusion_matrix(metrics):
    cm = metrics["confusion_matrix"]
    labels = metrics["labels"]
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Purples", xticklabels=labels, yticklabels=labels, ax=ax)
    ax.set_title(f"Classifier Confusion Matrix (Accuracy: {metrics['accuracy']:.1%})")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    fig.tight_layout()
    fig.savefig(os.path.join(VIZ_DIR, "06_confusion_matrix.png"), dpi=150)
    plt.close(fig)


def write_insights_report(df, metrics):
    total = len(df)
    counts = df["lexicon_sentiment"].value_counts()
    pos_pct = counts.get("positive", 0) / total * 100
    neg_pct = counts.get("negative", 0) / total * 100
    neu_pct = counts.get("neutral", 0) / total * 100

    worst_product = (
        pd.crosstab(df["product"], df["lexicon_sentiment"], normalize="index")
        .get("negative", pd.Series(dtype=float))
        .idxmax()
    )
    best_product = (
        pd.crosstab(df["product"], df["lexicon_sentiment"], normalize="index")
        .get("positive", pd.Series(dtype=float))
        .idxmax()
    )

    neg_tokens = [t for toks in df.loc[df["lexicon_sentiment"] == "negative", "tokens"] for t in toks]
    top_complaints = [w for w, _ in Counter(neg_tokens).most_common(5)]

    report = f"""# Amazon Customer Sentiment Analysis — Insights Report

## Dataset Overview
- Total reviews analyzed: **{total}**
- Products covered: **{df['product'].nunique()}**
- Date range: **{df['date'].min().date()}** to **{df['date'].max().date()}**

## Sentiment Distribution
| Sentiment | % of Reviews |
|---|---|
| Positive | {pos_pct:.1f}% |
| Neutral  | {neu_pct:.1f}% |
| Negative | {neg_pct:.1f}% |

## Classification Model Performance
A TF-IDF + Logistic Regression classifier was trained on rating-derived
sentiment labels and evaluated on a held-out 25% test split.

- **Accuracy:** {metrics['accuracy']:.1%}

```
{metrics['report']}
```

## Key Patterns
- **Best-performing product** (highest share of positive reviews): **{best_product}**
- **Product needing attention** (highest share of negative reviews): **{worst_product}**
- **Most common complaint terms:** {', '.join(top_complaints) if top_complaints else 'n/a'}

## Recommendations for Product Improvement
1. Prioritize a quality review for **{worst_product}**, focusing on the
   recurring complaint themes above (durability, defects, or usability
   issues typically drive negative sentiment).
2. Use **{best_product}**'s positive review language as a template for
   marketing copy and product listing highlights.
3. Monitor the weekly sentiment trend chart for spikes in negative
   sentiment following shipments — this often correlates with a bad batch
   or packaging issue.
4. Since neutral reviews ({neu_pct:.1f}%) often signal room for
   improvement without outright dissatisfaction, consider proactive
   customer outreach or feedback surveys targeted at 3-star reviewers.

## Files Generated
- `outputs/sentiment_results.csv` — per-review sentiment results
- `outputs/visualizations/01_sentiment_distribution.png`
- `outputs/visualizations/02_sentiment_by_rating.png`
- `outputs/visualizations/03_sentiment_trend.png`
- `outputs/visualizations/04_sentiment_by_product.png`
- `outputs/visualizations/05_top_words.png`
- `outputs/visualizations/06_confusion_matrix.png`
"""
    with open(os.path.join(OUT_DIR, "insights_report.md"), "w") as f:
        f.write(report)


if __name__ == "__main__":
    run_pipeline()
