"""
preprocess.py
-------------
Lightweight, dependency-free text cleaning for review data
(no external NLTK/corpora downloads required).
"""

import re

STOPWORDS = set("""
a an the is are was were be been being i me my we our you your he she it
they them his her its their this that these those and or but if then so
because as of at by for with about into through during before after above
below to from up down in out on off over under again further once here
there when where why how all any both each few more most other some such
no nor not only own same than too very s t can will just don should now
have has had do does did doing having having's
""".split())


def clean_text(text: str) -> str:
    """Lowercase, strip punctuation/numbers, collapse whitespace."""
    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text: str):
    return [w for w in text.split() if w not in STOPWORDS and len(w) > 2]


def preprocess_series(series):
    """Return (cleaned_text_series, tokens_series)."""
    cleaned = series.apply(clean_text)
    tokens = cleaned.apply(tokenize)
    return cleaned, tokens
