"""
sentiment_model.py
-------------------
Two complementary sentiment techniques, as commonly required for this kind
of assignment:

1. Lexicon-based scoring (fast, unsupervised, no training data needed).
2. A supervised ML classifier (TF-IDF + Logistic Regression) trained on
   ratings-derived labels, evaluated with a held-out test set.
"""

import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

POSITIVE_WORDS = set("""
good great excellent amazing love loved perfect best awesome fantastic
happy nice wonderful comfortable sturdy fast easy recommend recommended
flawless value quality exceeded reliable durable smooth
""".split())

NEGATIVE_WORDS = set("""
bad terrible awful worst hate hated poor disappointed disappointing
broke broken cheap flimsy useless waste regret damaged unhelpful
stopped uncomfortable slow difficult unclear defective faulty
""".split())


def lexicon_sentiment(tokens):
    """Rule-based polarity score -> 'positive' | 'negative' | 'neutral'."""
    pos = sum(1 for t in tokens if t in POSITIVE_WORDS)
    neg = sum(1 for t in tokens if t in NEGATIVE_WORDS)
    score = pos - neg
    if score > 0:
        return "positive", score
    elif score < 0:
        return "negative", score
    return "neutral", score


def rating_to_label(rating):
    if rating >= 4:
        return "positive"
    elif rating <= 2:
        return "negative"
    return "neutral"


def train_classifier(df, text_col="cleaned_text", label_col="rating_label"):
    """Train TF-IDF + Logistic Regression classifier, return model, vectorizer, metrics."""
    X_train, X_test, y_train, y_test = train_test_split(
        df[text_col], df[label_col], test_size=0.25, random_state=42, stratify=df[label_col]
    )

    vectorizer = TfidfVectorizer(max_features=2000, ngram_range=(1, 2))
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    clf = LogisticRegression(max_iter=1000, class_weight="balanced")
    clf.fit(X_train_vec, y_train)

    y_pred = clf.predict(X_test_vec)

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "report": classification_report(y_test, y_pred, output_dict=False),
        "confusion_matrix": confusion_matrix(y_test, y_pred, labels=["positive", "neutral", "negative"]),
        "labels": ["positive", "neutral", "negative"],
    }
    return clf, vectorizer, metrics
